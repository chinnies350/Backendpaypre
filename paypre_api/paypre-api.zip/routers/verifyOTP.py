from fastapi.routing import APIRouter
from schemas import VerifyOTP
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from random import randint
import re
from routers.utils.apiCommon import ApiWithProcedureOTP, additionalFunctionOTP

router = APIRouter(prefix='/verifyOTP', tags=['VerifyOTP'])


@router.post('')
async def verifyOTP(request: VerifyOTP, db:Cursor = Depends(get_cursor)):
    OTP = randint(100000, 999999)
    regex = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
    Pattern = re.compile("(0|91)?[6-9][0-9]{9}")
    if Pattern.match(request.UserName):
        query = 'EXEC VerifyOTP @UserName =?'
        queryParams = (request.UserName)

        return await ApiWithProcedureOTP(db=db, 
                                        query=query, 
                                        queryParams=queryParams, 
                                        additionalFunction=additionalFunctionOTP,
                                        OTP=OTP
                                        )
    elif re.fullmatch(regex, request.UserName):
        query = 'EXEC VerifyOTP @UserName =?'
        queryParams = (request.UserName)

        return await ApiWithProcedureOTP(db=db, 
                                        query=query, 
                                        queryParams=queryParams, 
                                        additionalFunction=additionalFunctionOTP,
                                        OTP=OTP
                                        )
        