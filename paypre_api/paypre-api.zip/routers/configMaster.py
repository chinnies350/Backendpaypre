from fastapi.routing import APIRouter
from schemas import PostConfigMaster, PutConfigMaster
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from routers.utils.apiCommon import ApiWithProcedure, ApiWithProcedureGet,additionalFunctionPost, additionalFunctionPut, additionalFunctionDelete



router = APIRouter(prefix='/configMaster', tags=['ConfigMaster'])

@router.get('')
async def configMasterGet(TypeId:Optional[int] = Query(None), ActiveStatus:Optional[str] = Query(None), TypeName: Optional[str]=Query(None), ConfigId:Optional[int]=Query(None), db:Cursor= Depends(get_cursor)):
    query = 'EXEC getConfigMaster @TypeId=?, @ActiveStatus=?, @TypeName=?, @ConfigId=?'
    queryParams = ( TypeId, ActiveStatus, TypeName, ConfigId)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)

@router.post('')
async def configMasterPost(request: PostConfigMaster, db:Cursor= Depends(get_cursor)):
    query = 'EXEC postConfigMaster @TypeId=?, @ConfigName=?, @AlphaNumFld=?, @NumFld=?, @SmallIcon=?, @CreatedBy=?'
    queryParams = (  request.TypeId, request.ConfigName, request.AlphaNumFld, request.NumFld, request.SmallIcon, request.CreatedBy)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPost)

@router.put('')
async def configMasterPut(request: PutConfigMaster, db:Cursor = Depends(get_cursor)):
    query = 'EXEC putConfigMaster @TypeId=?, @ConfigName=?, @AlphaNumFld=?, @NumFld=?, @SmallIcon=?, @UpdatedBy=?, @ConfigId=?'
    queryParams = ( request.TypeId, request.ConfigName, request.AlphaNumFld, request.NumFld, request.SmallIcon, request.UpdatedBy, request.ConfigId)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)

@router.delete('')
async def configMasterPut(UpdatedBy: int, ConfigId: int, ActiveStatus: str,db:Cursor = Depends(get_cursor)):
    query = 'EXEC deleteConfigMaster @UpdatedBy=?, @ConfigId=?, @ActiveStatus=?'
    queryParams = (  UpdatedBy, ConfigId, ActiveStatus)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionDelete)




