from routers.utils.errorHandling import handleError
from routers.utils.statusCodes import FAILED, SUCCESS
from routers.utils.responseMessages import NOT_ADD, ADD_MSG, ALREADY_EXISTS, NOT_UPDATE, UPDATE_MSG, DELETE_MSG, NOT_DELETE, NOT_FOUND, FOUND, OTP
import json
import pyodbc
from typing import List,Dict

async def ApiWithProcedure(db, query, queryParams, additionalFunction):
    try:
        print('queryParams', queryParams)
        print(f"""{query}""", queryParams)
        await db.execute(f"""{query}""", queryParams)
        res = await db.fetchall()
        return additionalFunction(res)
    except pyodbc.Error as pe:
         print(str(pe))
         return {
              'response': 'DataBase error ',
              'statusCode': FAILED
         }
    except Exception as e:
        def errorFunc(e):
            return e
        return handleError(e, errorFunc)

async def ApiWithProcedureTrans(db, query, request,transformParam, additionalFunction):
    try:
        print('queryParams', queryParams)
        print(f"""{query}""", queryParams)
        queryParams = transformParam(request)
        await db.execute(f"""{query}""", queryParams)
        res = await db.fetchall()
        return additionalFunction(res)
    except Exception as e:
        def errorFunc(e):
            return e
        return handleError(e, errorFunc)
    
async def ApiWithProcedureGet(db, query, queryParams, additionalFunction=None, dataTransform=None):
    try:
        print('queryParams', queryParams)
        print(f"""{query}""", queryParams)
        await db.execute(f"""{query}""", queryParams)
        res = await db.fetchall()
        if additionalFunction: 
            return additionalFunction(res,dataTransform if dataTransform else getData)
        else:
             return additionalFunctionGet(res,dataTransform if dataTransform else getData)
    except Exception as e:
        def errorFunc(e):
            return e
        return handleError(e, errorFunc)

def getData(res):
    data = FOUND
    data['data'] = json.loads(res) 
    return data

def additionalFunctionGet(res, getData=None):
        print('res', res)
        if len(res) == 0:
            return NOT_FOUND
        elif res[0][0] != None:
            return getData(res[0][0])
        else: 
            return NOT_FOUND
    
def additionalFunctionPost(res):
        if len(res) == 0:
            return ALREADY_EXISTS
        elif res[0][1] == 0:
            return NOT_ADD
        elif res[0][1] == 2:
            return ALREADY_EXISTS
        else: 
            return ADD_MSG

def additionalFunctionPut(res):
        if len(res) == 0:
            return NOT_UPDATE
        elif res[0][1] == 0:
            return NOT_UPDATE
        elif res[0][1] == 2:
            return ALREADY_EXISTS
        else: 
            return UPDATE_MSG

def additionalFunctionDelete(res):
        if len(res) == 0:
            return NOT_DELETE
        elif res[0][1] == 0:
            return NOT_DELETE
        else: 
            return DELETE_MSG
        
async def ApiWithProcedureOTP(db, query, queryParams, additionalFunction, OTP):
    try:
        print('queryParams', queryParams)
        print(f"""{query}""", queryParams)
        await db.execute(f"""{query}""", queryParams)
        res = await db.fetchall()
        print('len',len(res))
        return additionalFunction(res, OTP)
    except pyodbc.Error as pe:
         print(str(pe))
         return {
              'response': 'DataBase error ',
              'statusCode': FAILED
         }
    except Exception as e:
        def errorFunc(e):
            return e
        return handleError(e, errorFunc)
        
def additionalFunctionOTP(res: List, OTP: str) -> Dict:
    if len(res) == 0:
        return {
            'statusCode': FAILED,
            'response': 'User not found'
        }
    elif res[0][0] == None:
        return {
            'statusCode': FAILED,
            'response': 'OTP could not be sent'
        }
    else:
        return {
            'statusCode': SUCCESS,
            'response': 'OTP sent successfully',
            'OTP': OTP
        }
