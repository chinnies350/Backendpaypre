def handleError(error, callback):
    return callback(str(error))