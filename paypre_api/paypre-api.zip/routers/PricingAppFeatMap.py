from fastapi.routing import APIRouter
from schemas import PostPricingAppFeatMap
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from routers.utils.apiCommon import ApiWithProcedure, ApiWithProcedureGet,additionalFunctionPost, additionalFunctionPut, additionalFunctionDelete



router = APIRouter(prefix='/pricingAppFeatMap', tags=['PricingAppFeatMap'])

@router.get('')
async def pricingAppFeatMapGet(ActiveStatus:Optional[str]=Query(None), AppId:Optional[int]=Query(None),db:Cursor= Depends(get_cursor)):
    query = 'EXEC getPricingAppFeatMap @ActiveStatus=?, @AppId=?'
    queryParams = ( ActiveStatus, AppId)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)

@router.post('')
async def pricingAppFeatMapPost(request: PostPricingAppFeatMap, db:Cursor= Depends(get_cursor)):
    query = 'EXEC postPricingAppFeatMap @AppId=?,@PricingId =?, @FeatId=?, @CreatedBy=?'
    queryParams = ( request.AppId, request.PricingId, request.FeatId, request.CreatedBy)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPost)



@router.delete('')
async def pricingAppFeatMapDelete(UpdatedBy: int, UniqueId: int, ActiveStatus: str,db:Cursor = Depends(get_cursor)):
    query = 'EXEC deletePricingAppFeatMap @UpdatedBy=?, @UniqueId =?, @ActiveStatus=?'
    queryParams = (  UpdatedBy, UniqueId , ActiveStatus)
    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionDelete)




