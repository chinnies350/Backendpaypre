from fastapi.routing import APIRouter
from schemas import PostUser,PutUser
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from routers.utils.apiCommon import ApiWithProcedure, ApiWithProcedureGet,additionalFunctionPost, additionalFunctionPut, additionalFunctionDelete


router = APIRouter(prefix='/user', tags=['User'])

@router.get('')
async def userGet(UserId:Optional[int] = Query(None), ActiveStatus:Optional[str] = Query(None), db:Cursor= Depends(get_cursor)):
    query = 'EXEC getUser @UserId=?, @ActiveStatus=?'
    queryParams = ( UserId, ActiveStatus)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)


@router.post('')
async def userPost(request: PostUser, db:Cursor= Depends(get_cursor)):
    query = f"""EXEC postUser @UserType=?, @CompId=?, @BranchId=?, @MobileNo=?, @MailId=?, @UserName=?, @UserImage=?, @Password=?, @Pin=?, @CreatedBy=?"""
    queryParams = (  request.UserType, request.CompId, request.BranchId, request.MobileNo, request.MailId, request.UserName, request.UserImage ,request.Password, request.Pin, request.CreatedBy )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPost)
    
@router.put('')
async def userPut(request: PutUser, db:Cursor = Depends(get_cursor)):
    query = f"""EXEC putUser @UserType=?, @CompId=?, @BranchId=?, @MobileNo=?, @MailId=?, @UserName=?, @UserImage=?, @Password=?, @Pin=?, @UpdatedBy=?, @UserId=?"""
    queryParams = ( request.UserType, request.CompId, request.BranchId, request.MobileNo, request.MailId, request.UserName, request.UserImage ,request.Password, request.Pin, request.UpdatedBy, request.UserId )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)
    
@router.delete('')
async def userdelete(UserId: int, ActiveStatus: str, UpdatedBy: int, db:Cursor = Depends(get_cursor)):
    query = 'EXEC deleteUser @UserId=?, @ActiveStatus=?, @UpdatedBy=?'
    queryParams = (  UserId, ActiveStatus, UpdatedBy)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionDelete)