from fastapi import FastAPI
from routers.utils.responseMessages import WELCOME_MESSAGE
from fastapi.middleware.cors import CORSMiddleware

from routers import configType, configMaster, carousel, applicationMaster, feature, currency, pricingType, PricingAppFeatMap, appImage, UserAppMap, company,branch,user,compAppMap,appMenu,adminTax,forgotpassword,changepassword,login,verifyOTP,gmailLogin

app = FastAPI()

origins = ['*']

app.add_middleware(CORSMiddleware, 
                   allow_origins=origins,
                   allow_credentials=True,
                   allow_methods=["*"],
                   allow_headers=["*"])

@app.get('/')
def home():
    return WELCOME_MESSAGE



app.include_router(configType.router)
app.include_router(configMaster.router)
app.include_router(carousel.router)
app.include_router(company.router)
app.include_router(branch.router)
app.include_router(user.router)
app.include_router(compAppMap.router)
app.include_router(appMenu.router)
app.include_router(applicationMaster.router)
app.include_router(feature.router)
app.include_router(currency.router)
app.include_router(pricingType.router)
app.include_router(PricingAppFeatMap.router)
app.include_router(appImage.router)
app.include_router(UserAppMap.router)
app.include_router(adminTax.router)
app.include_router(forgotpassword.router)
app.include_router(changepassword.router)
app.include_router(login.router)
app.include_router(verifyOTP.router)
app.include_router(gmailLogin.router)


origins = ['*']

app.add_middleware(CORSMiddleware, 
                   allow_origins=origins,
                   allow_credentials=True,
                   allow_methods=["*"],
                   allow_headers=["*"])

