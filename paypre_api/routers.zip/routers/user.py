from fastapi.routing import APIRouter
from schemas import PostUser,PutUser,PutPassword,PutPin,PutUserProfile
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from routers.utils.apiCommon import ApiWithProcedure, ApiWithProcedureGet,additionalFunctionPost, additionalFunctionPut, additionalFunctionDelete


router = APIRouter(prefix='/user', tags=['User'])

@router.get('')
async def userGet(UserId:Optional[int] = Query(None), ActiveStatus:Optional[str] = Query(None), MobileNo:Optional[str] = Query(None) ,UserType:Optional[str] = Query(None) ,db:Cursor= Depends(get_cursor)):
    query = 'EXEC getUser @UserId=?, @ActiveStatus=?,@MobileNo=? ,@UserType=?'
    queryParams = ( UserId, ActiveStatus, MobileNo, UserType)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)


@router.post('')
async def userPost(request: PostUser, db:Cursor= Depends(get_cursor)):
    query = f"""EXEC postUser @UserType=?, @CompId=?, @BranchId=?, @MobileNo=?, @MailId=?, @UserName=?, @UserImage=?, @Password=?, @Pin=?, @CreatedBy=?"""
    queryParams = (  request.UserType, request.CompId, request.BranchId, request.MobileNo, request.MailId, request.UserName, request.UserImage ,request.Password, request.Pin, request.CreatedBy )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPost)
    
@router.put('')
async def userPut(request: PutUser, db:Cursor = Depends(get_cursor)):
    query = f"""EXEC putUser @UserType=?, @CompId=?, @BranchId=?, @MobileNo=?, @MailId=?, @UserName=?, @UserImage=?, @Password=?, @Pin=?, @UpdatedBy=?, @UserId=?"""
    queryParams = ( request.UserType, request.CompId, request.BranchId, request.MobileNo, request.MailId, request.UserName, request.UserImage ,request.Password, request.Pin, request.UpdatedBy, request.UserId )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)
    
@router.delete('')
async def userdelete(UserId: int, ActiveStatus: str, UpdatedBy: int, db:Cursor = Depends(get_cursor)):
    query = 'EXEC deleteUser @UserId=?, @ActiveStatus=?, @UpdatedBy=?'
    queryParams = (  UserId, ActiveStatus, UpdatedBy)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionDelete)
    
    
@router.put('/setPassword')
async def userPutPassword(request: PutPassword, db:Cursor= Depends(get_cursor)):
    query = f"""EXEC putUserPassword @Password=?, @UpdatedBy=?,@UserId=?"""
    queryParams = (  request.Password,request.UpdatedBy,request.UserId )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)
    


@router.put('/setPin')
async def userPutPin(request: PutPin, db:Cursor= Depends(get_cursor)):
    query = f"""EXEC putUserPin @Pin=?, @UpdatedBy=?,@UserId=?"""
    queryParams = (  request.Pin,request.UpdatedBy,request.UserId )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)
    
@router.put('/updateUserProfile')
async def userPutProfile(request: PutUserProfile, db:Cursor = Depends(get_cursor)):
    query = f"""EXEC putUserProfile @MobileNo=?, @MailId=?, @UserName=?, @UserImage=?, @UpdatedBy=?, @UserId=?"""
    queryParams = ( request.MobileNo, request.MailId, request.UserName, request.UserImage, request.UpdatedBy, request.UserId )

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)