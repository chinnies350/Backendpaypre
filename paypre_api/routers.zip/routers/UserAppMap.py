from fastapi.routing import APIRouter
from schemas import PostUserAppMap, PutUserAppMapPayment, PostFreeOption, PutUPIPmtStatus
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from routers.utils.apiCommon import ApiWithProcedure, ApiWithProcedureGet,additionalFunctionPost,additionalFunctionPostUserMapp, additionalFunctionPut, additionalFunctionDelete



router = APIRouter(prefix='/userAppMap', tags=['UserAppMap'])

@router.get('')
async def userAppMapGet(UniqueId:Optional[int]=Query(None), AppId:Optional[str]=Query(None), UserId:Optional[int]=Query(None),Type:Optional[str]=Query(None),PaymentStatus:Optional[str]=Query(None), db:Cursor= Depends(get_cursor)):
    query = 'EXEC getUserAppMap @UniqueId=?, @AppId=?, @UserId=?,@Type=?,@PaymentStatus=?'
    queryParams = ( UniqueId,AppId, UserId,Type,PaymentStatus)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)

@router.post('')
async def userAppMapPost(request: PostUserAppMap, db:Cursor= Depends(get_cursor)):
    query = 'EXEC postUserAppMap @UserId=?, @AppId=?, @PricingId=?, @CompId=?, @PurDate=?, @PaymentMode=?, @PaymentStatus=?, @LicenseStatus=?, @Price=?, @TaxId=?, @TaxAmount=?, @NetPrice=?, @ValidityStart=?, @ValidityEnd=?, @CreatedBy=?,@NoofDays=?'
    queryParams = ( request.UserId, request.AppId, request.PricingId, request.CompId, request.PurDate, request.PaymentMode, request.PaymentStatus, request.LicenseStatus, request.Price, request.TaxId, request.TaxAmount, request.NetPrice, request.ValidityStart, request.ValidityEnd ,request.CreatedBy,request.NoofDays)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPostUserMapp)

@router.put('/paymentStatus')
async def userAppMapPut(request: PutUserAppMapPayment, db:Cursor = Depends(get_cursor)):
    query = 'EXEC putUserAppMap @PaymentStatus=?, @UpdatedBy=?, @UniqueId=?'
    queryParams = ( request.PaymentStatus, request.UpdatedBy, request.UniqueId)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPut)
    
@router.post('/FreeOption')
async def userAppMapPost(request: PostFreeOption, db:Cursor= Depends(get_cursor)):
    query = 'EXEC postFreeOption @UserId=?, @AppId=?, @PricingId=?, @CompId=?, @PurDate=?, @PaymentMode=?, @PaymentStatus=?, @LicenseStatus=?, @Price=?, @TaxId=?, @TaxAmount=?, @NetPrice=?, @ValidityStart=?, @ValidityEnd=?, @CreatedBy=?'
    queryParams = ( request.UserId, request.AppId, request.PricingId, request.CompId, request.PurDate, request.PaymentMode, request.PaymentStatus, request.LicenseStatus, request.Price, request.TaxId, request.TaxAmount, request.NetPrice, request.ValidityStart, request.ValidityEnd ,request.CreatedBy)

    return await ApiWithProcedure(db=db, 
                                    query=query, 
                                    queryParams=queryParams, 
                                    additionalFunction=additionalFunctionPost)
    






