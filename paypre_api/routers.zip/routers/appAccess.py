from fastapi.routing import APIRouter
from schemas import PostAppAccess
from aioodbc.cursor import Cursor
from routers.config import get_cursor
from fastapi import Depends
from typing import Optional
from fastapi import Query
from typing import Tuple,Dict, List
import json
from joblib import Parallel, delayed
from routers.utils.apiCommon import ApiWithProcedure,ApiWithProcedureTrans, ApiWithProcedureGet,additionalFunctionPost, additionalFunctionPut, additionalFunctionDelete




router = APIRouter(prefix='/appAccess', tags=['AppAccess'])                   
def callFunction(i):
    return i.dict()

@router.get('')
async def userGet(UserId:Optional[int] = Query(None), AppId:Optional[int] = Query(None), CompId:Optional[int] = Query(None) ,db:Cursor= Depends(get_cursor)):
    query = 'EXEC getAppAccess @UserId=?, @AppId=?, @CompId=?'
    queryParams = ( UserId, AppId, CompId)

    return await ApiWithProcedureGet(db=db, 
                                        query=query, 
                                        queryParams=queryParams)



@router.post('')
async def postAppAccess(request: PostAppAccess, db:Cursor= Depends(get_cursor)):

    query = 'EXEC postAppAccess @UserId=?,@ModuleDetails =?,@CreatedBy=?'
    
    def transformFunction(request: PostAppAccess) -> Tuple:
        formattedData = []
        if request.ModuleDetails:
            appIds = list(set([data.AppId for data in request.ModuleDetails]))
            formattedData = [{"AppId": AppId} for AppId in appIds]
            
        return (request.UserId,json.dumps(formattedData), request.CreatedBy)

    
    return await ApiWithProcedureTrans(db=db, 
                                    query=query,
                                    request=request, 
                                    transformParam=transformFunction, 
                                    additionalFunction=additionalFunctionPost)
    







