# from sqlalchemy import create_engine
import asyncio
import aioodbc
from aioodbc.cursor import Cursor
from pymongo  import MongoClient
from concurrent.futures import ThreadPoolExecutor
from starlette.status import HTTP_502_BAD_GATEWAY
from starlette.exceptions import HTTPException
from pyodbc import OperationalError
from asyncio import AbstractEventLoop

# client = MongoClient("mongodb://admin:Prematix%40123@mongodb_server:27017/?authMechanism=DEFAULT")
client = MongoClient("mongodb://admin:Prematix%40123@192.168.1.16:7017/?authMechanism=DEFAULT")

db = client['paypre']

# Get a collection for logs
logs_collection = db['logs']

# engine = create_engine('mssql+pyodbc://paypreuser:password123@192.168.1.173/smart_parking?driver=ODBC+Driver+17+for+SQL+Server&Mars_Connection=Yes')

loop: AbstractEventLoop = asyncio.get_event_loop()

async def get_cursor() -> Cursor:
    dsn = r'Driver={ODBC Driver 17 for SQL Server};Server={192.168.1.221};Database={PayPre_Common_FrameWork};UID={appUser};PWD={AppUser@221#$*};MARS_Connection=yes;APP=yourapp'


    try:
        async with aioodbc.connect(dsn=dsn, loop=loop, executor= ThreadPoolExecutor(max_workers=50)) as conn:
            async with conn.cursor() as cur:
                yield cur
    except OperationalError:
        raise HTTPException(status_code=HTTP_502_BAD_GATEWAY,
                                detail='DB connectivity failed')






